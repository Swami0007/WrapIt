import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:uuid/uuid.dart';
import 'orders_screen.dart';

class CartScreen extends StatefulWidget {
  final String canteenId;
  final String canteenName;

  const CartScreen({
    super.key,
    required this.canteenId,
    required this.canteenName,
  });

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final user = FirebaseAuth.instance.currentUser;

  double _calculateTotal(List<QueryDocumentSnapshot<Map<String, dynamic>>> docs) {
    double total = 0;
    for (var doc in docs) {
      final data = doc.data();
      total += (data['price'] ?? 0) * (data['quantity'] ?? 1);
    }
    return total;
  }

  Future<void> _updateQuantity(DocumentReference ref, int newQty) async {
    if (newQty <= 0) {
      await ref.delete();
    } else {
      await ref.update({'quantity': newQty});
    }
  }

  /// 🔢 Generate a canteen-specific order number (e.g. ORD-M-0001)
  Future<String> _generateOrderNumber() async {
    // Take the first letter from canteen name or ID as prefix
    final prefix =
        widget.canteenName.isNotEmpty ? widget.canteenName[0].toUpperCase() : widget.canteenId[0].toUpperCase();

    final counterRef = FirebaseFirestore.instance
        .collection('canteens')
        .doc(widget.canteenId)
        .collection('meta')
        .doc('orderCounter');

    return FirebaseFirestore.instance.runTransaction((transaction) async {
      final snapshot = await transaction.get(counterRef);
      int current = 0;

      if (!snapshot.exists) {
        transaction.set(counterRef, {'count': 1});
        current = 1;
      } else {
        final data = snapshot.data();
        current = (data?['count'] ?? 0) + 1;
        transaction.update(counterRef, {'count': current});
      }

      return 'ORD-$prefix-${current.toString().padLeft(4, '0')}';
    });
  }

  Future<void> _confirmOrder({
    required List<QueryDocumentSnapshot<Map<String, dynamic>>> cartDocs,
    required String paymentRef,
    DateTime? prebookTime,
  }) async {
    try {
      if (user == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please login first!')),
        );
        return;
      }

      final orderId = const Uuid().v4();
      final total = _calculateTotal(cartDocs);
      final orderNumber = await _generateOrderNumber();

      final orderData = {
        'orderId': orderId,
        'orderNumber': orderNumber,
        'items': cartDocs.map((e) => e.data()).toList(),
        'total': total,
        'status': prebookTime == null ? 'Pending' : 'Prebooked',
        'timestamp': Timestamp.now(),
        'paymentRefId': paymentRef,
        'canteenId': widget.canteenId,
        'canteenName': widget.canteenName,
        if (prebookTime != null) 'prebookTime': Timestamp.fromDate(prebookTime),
      };

      // Save under user
      await FirebaseFirestore.instance
          .collection('users')
          .doc(user!.uid)
          .collection('orders')
          .doc(orderId)
          .set(orderData);

      // Save under canteen
      await FirebaseFirestore.instance
          .collection('canteens')
          .doc(widget.canteenId)
          .collection('orders')
          .doc(orderId)
          .set(orderData);

      // Clear cart
      final cartRef = FirebaseFirestore.instance
          .collection('users')
          .doc(user!.uid)
          .collection('cart');
      final cartSnapshot = await cartRef.get();
      for (var doc in cartSnapshot.docs) {
        await doc.reference.delete();
      }

      if (mounted) {
        Navigator.pop(context);
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => AlertDialog(
            title: const Text('Order Placed 🎉'),
            content: Text('Your order $orderNumber was placed successfully!'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (_) => const OrdersScreen()),
                  );
                },
                child: const Text('OK'),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      debugPrint('🔥 Order error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Order failed: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  /// 💳 QR + payment confirmation
  void _openPaymentScreen(
    double total,
    List<QueryDocumentSnapshot<Map<String, dynamic>>> cartDocs, {
    DateTime? prebookTime,
  }) {
    final refId = const Uuid().v4().substring(0, 8).toUpperCase();
    final upiLink =
        "upi://pay?pa=sreeharim776@oksbi&pn=WrapItCanteen&am=$total&cu=INR&tn=Order_$refId";

    final refController = TextEditingController();

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.teal,
            title: const Text('Payment'),
          ),
          body: Padding(
            padding: const EdgeInsets.all(20),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'Scan this QR to Pay',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 15),
                  Center(
                    child: QrImageView(
                      data: upiLink,
                      version: QrVersions.auto,
                      size: 220,
                      backgroundColor: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    'Order Ref ID: $refId',
                    style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      color: Colors.teal,
                    ),
                  ),
                  const SizedBox(height: 15),
                  const Text(
                    'After completing payment, enter your UPI Reference ID below:',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: refController,
                    decoration: const InputDecoration(
                      labelText: 'Payment Reference ID',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.check_circle),
                    label: const Text('I Have Paid'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      minimumSize: const Size.fromHeight(50),
                    ),
                    onPressed: () async {
                      final ref = refController.text.trim();
                      if (ref.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                          content: Text('Enter Payment Reference ID'),
                          backgroundColor: Colors.red,
                        ));
                        return;
                      }

                      showDialog(
                        context: context,
                        barrierDismissible: false,
                        builder: (_) =>
                            const Center(child: CircularProgressIndicator()),
                      );

                      await _confirmOrder(
                        cartDocs: cartDocs,
                        paymentRef: ref,
                        prebookTime: prebookTime,
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showPrebookDialog(
      List<QueryDocumentSnapshot<Map<String, dynamic>>> cartDocs, double total) {
    final now = DateTime.now();
    final close = DateTime(now.year, now.month, now.day, 17, 0);
    DateTime selected = now.add(const Duration(minutes: 30));

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Select Prebook Time'),
        content: StatefulBuilder(
          builder: (context, setState) => Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ElevatedButton(
                onPressed: () async {
                  final picked = await showTimePicker(
                    context: context,
                    initialTime: TimeOfDay.fromDateTime(selected),
                  );
                  if (picked != null) {
                    final dt = DateTime(
                      now.year,
                      now.month,
                      now.day,
                      picked.hour,
                      picked.minute,
                    );
                    if (dt.isAfter(now) && dt.isBefore(close)) {
                      setState(() => selected = dt);
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text('Invalid time!'),
                        backgroundColor: Colors.red,
                      ));
                    }
                  }
                },
                child: Text(DateFormat('hh:mm a').format(selected)),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _openPaymentScreen(total, cartDocs, prebookTime: selected);
            },
            child: const Text('Confirm'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (user == null) {
      return const Scaffold(body: Center(child: Text('Please login first')));
    }

    final cartStream = FirebaseFirestore.instance
        .collection('users')
        .doc(user!.uid)
        .collection('cart')
        .snapshots();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Cart'),
        backgroundColor: Colors.teal.shade100,
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: cartStream,
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final cartDocs = snapshot.data!.docs;
          if (cartDocs.isEmpty) return const Center(child: Text('Cart is empty'));
          final total = _calculateTotal(cartDocs);

          return Column(
            children: [
              Expanded(
                child: ListView.builder(
                  itemCount: cartDocs.length,
                  itemBuilder: (context, i) {
                    final data = cartDocs[i].data();
                    final qty = data['quantity'] ?? 1;
                    return ListTile(
                      leading: const Icon(Icons.fastfood, color: Colors.teal),
                      title: Text(data['name']),
                      subtitle: Text('₹${data['price']} × $qty'),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.remove_circle_outline, color: Colors.red),
                            onPressed: () => _updateQuantity(cartDocs[i].reference, qty - 1),
                          ),
                          Text('$qty'),
                          IconButton(
                            icon: const Icon(Icons.add_circle_outline, color: Colors.green),
                            onPressed: () => _updateQuantity(cartDocs[i].reference, qty + 1),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              Container(
                padding: const EdgeInsets.all(16),
                color: Colors.teal.shade50,
                child: Column(
                  children: [
                    Text(
                      'Total: ₹${total.toStringAsFixed(0)}',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton.icon(
                          icon: const Icon(Icons.payment),
                          label: const Text('Order Now'),
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                          onPressed: () => _openPaymentScreen(total, cartDocs),
                        ),
                        ElevatedButton.icon(
                          icon: const Icon(Icons.schedule),
                          label: const Text('Prebook'),
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                          onPressed: () => _showPrebookDialog(cartDocs, total),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
