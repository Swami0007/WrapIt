import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      return const Scaffold(
        body: Center(child: Text('Please log in to view your orders.')),
      );
    }

    final orderStream = FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('orders')
        .orderBy('timestamp', descending: true)
        .snapshots();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Orders'),
        backgroundColor: Colors.teal.shade100,
        foregroundColor: Colors.black,
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: orderStream,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final orders = snapshot.data!.docs;
          if (orders.isEmpty) {
            return const Center(child: Text('No orders yet.'));
          }

          return ListView.builder(
            padding: const EdgeInsets.all(10),
            itemCount: orders.length,
            itemBuilder: (context, index) {
              final order = orders[index].data();
              final orderNo = order['orderNumber'] ?? 'N/A';
              final total = order['total'] ?? 0;
              final status = order['status'] ?? 'Unknown';
              final refId = order['paymentRefId'] ?? 'Not Provided';
              final prebookTime = order['prebookTime'] != null
                  ? DateFormat('hh:mm a').format(order['prebookTime'].toDate())
                  : null;

              return Card(
                elevation: 3,
                margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Order #$orderNo',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          color: Colors.teal,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Total: ₹${total.toStringAsFixed(0)}',
                        style: const TextStyle(fontSize: 16),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Status: $status',
                        style: TextStyle(
                          fontSize: 16,
                          color: status == 'Completed'
                              ? Colors.green
                              : (status == 'Pending'
                                  ? Colors.orange
                                  : Colors.blueGrey),
                        ),
                      ),
                      if (prebookTime != null) ...[
                        const SizedBox(height: 4),
                        Text(
                          'Prebooked for: $prebookTime',
                          style: const TextStyle(fontSize: 15),
                        ),
                      ],
                      const SizedBox(height: 4),
                      Text(
                        'Payment Ref ID: $refId',
                        style: const TextStyle(fontSize: 15),
                      ),
                      const Divider(height: 20),
                      const Text(
                        'Items:',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, color: Colors.black54),
                      ),
                      const SizedBox(height: 5),
                      ...List.generate(
                        (order['items'] as List).length,
                        (i) {
                          final item = order['items'][i];
                          return Text(
                            '• ${item['name']} × ${item['quantity']}',
                            style: const TextStyle(fontSize: 14),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
