import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:canteen_app/screens/cart_screen.dart';
import 'package:canteen_app/screens/orders_screen.dart';

class MenuScreen extends StatelessWidget {
  final String canteenId;
  final String canteenName;

  const MenuScreen({
    super.key,
    required this.canteenId,
    required this.canteenName,
  });

  Future<void> addToCart(BuildContext context, Map<String, dynamic> item) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final userCart = FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('cart');

    final existingItems = await userCart.get();

    // 🔒 Restrict to one canteen at a time
    if (existingItems.docs.isNotEmpty) {
      final existingCanteen = existingItems.docs.first.data()['canteen'];
      if (existingCanteen != canteenName) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text(
              'You can only order from one canteen at a time.',
            ),
            action: SnackBarAction(
              label: 'Clear Cart',
              textColor: Colors.white,
              onPressed: () async {
                for (var doc in existingItems.docs) {
                  await doc.reference.delete();
                }
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('Cart cleared. You can now add from this canteen.'),
                  backgroundColor: Colors.green,
                ));
              },
            ),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }
    }

    final cartRef = userCart.doc(item['id'] ?? item['name']);
    await cartRef.set({
      'name': item['name'],
      'price': item['price'],
      'category': item['category'],
      'canteen': canteenName,
      'quantity': FieldValue.increment(1),
      'addedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${item['name']} added to cart!'),
        duration: const Duration(seconds: 2),
        backgroundColor: Colors.teal,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final stream = FirebaseFirestore.instance
        .collection('canteens')
        .doc(canteenId)
        .snapshots();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.teal.shade100,
        foregroundColor: Colors.black,
        title: Text('$canteenName Menu'),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            tooltip: 'View Cart',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => CartScreen(
                    canteenId: canteenId,
                    canteenName: canteenName,
                  ),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.receipt_long),
            tooltip: 'View Orders',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const OrdersScreen()),
              );
            },
          ),
        ],
      ),
      body: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        stream: stream,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          if (!snapshot.hasData || !snapshot.data!.exists) {
            return const Center(child: CircularProgressIndicator());
          }

          final data = snapshot.data!.data();
          if (data == null || data['menu'] == null) {
            return const Center(child: Text('No menu found.'));
          }

          final menuList = List<Map<String, dynamic>>.from(data['menu']);

          return ListView.builder(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
            itemCount: menuList.length,
            itemBuilder: (context, index) {
              final item = menuList[index];
              return Card(
                margin: const EdgeInsets.symmetric(vertical: 6),
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                child: ListTile(
                  contentPadding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
                  leading: CircleAvatar(
                    backgroundColor: Colors.teal.shade100,
                    child: const Icon(Icons.fastfood, color: Colors.teal),
                  ),
                  title: Text(
                    item['name'],
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  subtitle: Text(item['category'],
                      style: const TextStyle(color: Colors.black54)),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        '₹${item['price']}',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.teal,
                        ),
                      ),
                      const SizedBox(width: 10),
                      IconButton(
                        icon: const Icon(Icons.add_circle,
                            color: Colors.teal, size: 26),
                        onPressed: () async {
                          await addToCart(context, item);
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
